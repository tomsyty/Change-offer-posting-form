async function readDataFromLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(data, (result) => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError.message)) : resolve(result);
    });
  });
}

async function saveDataToLocalStorage(data) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(data, () => {
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError.message)) : resolve(true);
    });
  });
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt changeOfferPostingForm');

  let readedValue;
  try {
    readedValue = await readDataFromLocalStorage(['hiddenCards']);
    if (!readedValue.hiddenCards) await saveDataToLocalStorage({ hiddenCards: [] });
  } catch (error) {
    toastMessage(`Błąd! ${error?.message ? error.message : error}`);
    return;
  }

  let previousUrl = '';

  const urlObserver = new MutationObserver(async () => {
    if (window.location.href !== previousUrl) {
      previousUrl = window.location.href;
      await changeOfferPostingForm();
    }
  });	
  urlObserver.observe(document, {	subtree: true, childList: true });

  if (window.location.href !== previousUrl) {
    previousUrl = window.location.href;
    try {
      await changeOfferPostingForm();
    } catch (error) {
      toastMessage(`Błąd! ${error?.message ? error.message : error}`);
    }
  }
});

async function changeOfferPostingForm(clickedElement) {
  let hiddenCards;
  let readedValue;
    try {
      readedValue = await readDataFromLocalStorage(['hiddenCards']);
      hiddenCards = readedValue.hiddenCards;
    } catch (error) {
      toastMessage(`Błąd! ${error?.message ? error.message : error}`);
      return;
    }

  if (clickedElement) {
    if (hiddenCards.includes(clickedElement)) {
      let divElement = document.getElementById(clickedElement);
      if (divElement.querySelector('div > details')) return;

      let detailsElement = document.createElement('details');
      let summaryElement = document.createElement('summary');
      let headerElement = divElement.querySelector('h2');
      if (!headerElement) {
        if (divElement.id === 'add-next-product') {
          headerElement = document.createElement('h2');
          headerElement.className = divElement.previousElementSibling.querySelector('h2').className;
          headerElement.textContent = 'Dodaj kolejny produkt';
          headerElement.addEventListener('mousedown', headerElementMouseDown);
          headerElement.addEventListener('mouseup', headerElementMouseUp);
          divElement.insertAdjacentElement('afterbegin', headerElement);
        } else if (divElement.id === 'who-can-buy') {
          headerElement = document.createElement('h2');
          headerElement.className = divElement.previousElementSibling.querySelector('h2').className;
          headerElement.textContent = 'Kto może kupić ofertę';
          headerElement.addEventListener('mousedown', headerElementMouseDown);
          headerElement.addEventListener('mouseup', headerElementMouseUp);
          divElement.insertAdjacentElement('afterbegin', headerElement);
        }
      }

      if (divElement.id === 'allegro-ads-card') headerElement.style.display = 'inline-flex';
      else headerElement.style.display = 'inline';

      summaryElement.appendChild(headerElement);
      detailsElement.appendChild(summaryElement);
  
      const children = Array.from(divElement.childNodes);
      children.forEach(child => {
        if (child !== detailsElement) {
          detailsElement.appendChild(child);
        }
      });
      divElement.appendChild(detailsElement);     
    } else {
      let divElement = document.getElementById(clickedElement);
      if (!divElement.querySelector('div > details')) return;
      
      let detailsElement = divElement.querySelector('details');
      let summaryElement = detailsElement.querySelector('summary');
  
      const children = Array.from(detailsElement.childNodes);
      children.forEach(child => {
        if (child === summaryElement && (divElement.id === 'who-can-buy' || divElement.id === 'add-next-product'));
        else if (child === summaryElement) {
          divElement.append(summaryElement.firstElementChild);
        } else {
          divElement.append(child);
        }
      });

      detailsElement.remove();
    }
    return;
  } 

  let sellForm;
  do {
    sellForm = document.getElementById('sellForm');
    if (!sellForm || !sellForm.querySelector('div[id="summary-card"]')) {
      console.log('changeOfferPostingForm: oczekiwanie na formularz wystawiania aukcji');
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  } while (sellForm === null || !sellForm.querySelector('div[id="summary-card"]'));
  console.log('changeOfferPostingForm: znaleziono formularz wystawiania aukcji');
  await new Promise(resolve => setTimeout(resolve, 2000));


  let sellFormDivs = Array.from(sellForm.querySelectorAll('form > div[class~="msts_pt"]'));
  sellFormDivs.shift();
  sellFormDivs.pop();

  for (let divElement of sellFormDivs) {
    if (divElement.querySelector('div > details')) break;
    if (divElement?.id === 'attributes-card' || divElement?.id === 'description-card') continue;
    if (divElement?.id === '' && divElement.previousElementSibling?.id === 'attachments-card') divElement.id = 'who-can-buy';

    if (!divElement.querySelector('h2')) {
      if (divElement.previousElementSibling?.id === 'attributes-card') {
        divElement.id = 'add-next-product';
        const buttonElement = divElement.querySelector('button');
        buttonElement.addEventListener('mousedown', headerElementMouseDown);
        buttonElement.addEventListener('mouseup', headerElementMouseUp);
      } else if (divElement.previousElementSibling?.id === 'attachments-card') {
        divElement.id = 'who-can-buy';
        const headerElement = divElement.querySelector('h3');
        headerElement.addEventListener('mousedown', headerElementMouseDown);
        headerElement.addEventListener('mouseup', headerElementMouseUp);
      }
    } else {
      let headerElement;
      headerElement = divElement.querySelector('h2,h3');
      headerElement.addEventListener('mousedown', headerElementMouseDown);
      headerElement.addEventListener('mouseup', headerElementMouseUp);
    }

    if (hiddenCards.includes(divElement.id)) {
      let detailsElement = document.createElement('details');
      let summaryElement = document.createElement('summary');
      let headerElement = divElement.querySelector('h2');
      if (!headerElement) {
        if (divElement.id === 'add-next-product') {
          headerElement = document.createElement('h2');
          headerElement.className = divElement.previousElementSibling.querySelector('h2').className;
          headerElement.textContent = 'Dodaj kolejny produkt';
          headerElement.addEventListener('mousedown', headerElementMouseDown);
          headerElement.addEventListener('mouseup', headerElementMouseUp);
          divElement.insertAdjacentElement('afterbegin', headerElement);
        } else if (divElement.id === 'who-can-buy') {
          headerElement = document.createElement('h2');
          headerElement.className = divElement.previousElementSibling.querySelector('h2').className;
          headerElement.textContent = 'Kto może kupić ofertę';
          headerElement.addEventListener('mousedown', headerElementMouseDown);
          headerElement.addEventListener('mouseup', headerElementMouseUp);
          divElement.insertAdjacentElement('afterbegin', headerElement);
        }
      }
      if (divElement.id === 'allegro-ads-card') headerElement.style.display = 'inline-flex';
      else headerElement.style.display = 'inline';

      summaryElement.appendChild(headerElement);
      detailsElement.appendChild(summaryElement);
  
      const children = Array.from(divElement.childNodes);
      children.forEach(child => {
        if (child !== detailsElement) {
          detailsElement.appendChild(child);
        }
      });
      divElement.appendChild(detailsElement);     
    }
  }
  return true;
}

async function headerElementMouseDown(e) {
  const divElement = e.target.closest('div[class~="msts_pt"]');
  divElement.dataset.clickTimer = setTimeout(async () => {
    let response;
    let readedValue;
    
    try {
      readedValue = await readDataFromLocalStorage(['hiddenCards']);
    } catch (error) {
      toastMessage(`Błąd! ${error?.message ? error.message : error}`);
      return;
    }

    if (readedValue.hiddenCards.includes(divElement.id) === false) {
      readedValue.hiddenCards.push(divElement.id);
      try {
        response = await saveDataToLocalStorage({ hiddenCards: readedValue.hiddenCards });
        toastMessage('Ta karta będzie zwinięta');
        divElement.classList.add('flash');
        setTimeout(() => divElement.classList.remove('flash'), 1200);
        changeOfferPostingForm(divElement.id);
      } catch (error) {
        toastMessage(`Błąd! ${error?.message ? error.message : error}`);
        return;
      }
    } else {
      readedValue.hiddenCards = readedValue.hiddenCards.filter(id => id !== divElement.id);
      try {
        response = await saveDataToLocalStorage({ hiddenCards: readedValue.hiddenCards });
        toastMessage('Ta karta nie będzie już zwinięta');  
        divElement.classList.add('flash');
        setTimeout(() => divElement.classList.remove('flash'), 1200);
        changeOfferPostingForm(divElement.id);  
      } catch (error) {
        toastMessage(`Błąd! ${error?.message ? error.message : error}`);
        return;
      }
    }
  }, 2000);
}

async function headerElementMouseUp(e) {
  const divElement = e.target.closest('div[class~="msts_pt"]');
  const clickTimer = divElement.dataset?.clickTimer;
  clearTimeout(clickTimer);
  delete divElement.dataset?.clickTimer;
}