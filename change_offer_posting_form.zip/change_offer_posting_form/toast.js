function toastMessage(message) {
	if (!message) return;
	let toast = document.getElementById('aeToast');
	if (toast === null) {
		toast = document.createElement('div');
		toast.id = 'aeToast';
		toast.classList.add('aeToastHidden');
		document.body.appendChild(toast);
	}
	const existingMessages = toast.querySelectorAll('.aeToastMessage');
	if (existingMessages.length) {
		const existingMessage = Array.from(existingMessages).find(element => (element.innerHTML.split('<span class="aeToastMessageCounter')[0]) === message);
		if (existingMessage !== undefined) {
			const existingMessageCounter = existingMessage.querySelector('.aeToastMessageCounter');
			existingMessageCounter.dataset.counter = Number(existingMessageCounter.dataset.counter) + 1;
			existingMessageCounter.classList.add('aeShowCounter');
			if (!(message.startsWith('Błąd') || message.startsWith('Uwaga'))) {
				const timer = existingMessage.dataset.timer;
				clearTimeout(timer);
				existingMessage.dataset.timer = setTimeout(() => {
					const message = document.getElementById(existingMessage.id);
					message.remove();
					const toast = document.getElementById('aeToast');
					if (!toast.childElementCount) toast.classList.add('aeToastHidden');
				}, 5000);
			}
			if (toast.firstChild !== existingMessage) {
				toast.insertAdjacentHTML('afterbegin', '<span></span>');
				toast.firstElementChild.replaceWith(existingMessage);
			}
			return;
		}
	}
	const newMessage = document.createElement('span');
	const counter = document.createElement('span');
	counter.classList.add('aeToastMessageCounter');
	counter.dataset.counter = '1';
	newMessage.classList.add('aeToastMessage');
	newMessage.innerHTML = message;
	newMessage.dataset.timer = '';
	newMessage.id = 'message_' + Date.now();
	newMessage.addEventListener('mouseenter', function () {
		const timer = this.dataset.timer;
		clearTimeout(timer);
		this.addEventListener('mouseleave', function () {
			this.remove();
			const toast = document.getElementById('aeToast');
			if (!toast.childElementCount) toast.classList.add('aeToastHidden');
		});
	});
	if (message.startsWith('Błąd')) newMessage.classList.add('aeToastError');
	else if (message.startsWith('Uwaga')) newMessage.classList.add('aeToastWarning');
	else {
		newMessage.dataset.timer = setTimeout(() => {
			const message = document.getElementById(newMessage.id);
			message.remove();
			let toast = document.getElementById('aeToast');
			if (!toast.childElementCount) toast.classList.add('aeToastHidden');
		}, 5000);
	}
	toast.insertAdjacentElement('afterbegin', newMessage);
	newMessage.appendChild(counter);
	toast.classList.remove('aeToastHidden');
	if (newMessage.querySelectorAll('a').length) {
		for (const link of newMessage.querySelectorAll('a')) {
			if (link.href.indexOf('chrome://') === 0) {
				link.addEventListener('click', (e) => {
					e.preventDefault();
					chrome.tabs.create({ url: e.target.href });
				});
			};
		}
	}
}